﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Nemesys.Models;

namespace Nemesys.ViewModels
{
    public class ReportListViewModel
    {
        public int TotalEntries { get; set; }

        public IEnumerable<Report> Reports { get; set; }

        public int ReportId { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public DateTime DateOfHazard { get; set; }
        public string Title { get; set; }
        public string Location { get; set; }
        public string TypeOfHazard { get; set; }
        public string Content { get; set; }
        public string Photo { get; set; }
        public string Upvotes { get; set; }
        public int ReadCount { get; set; }
        public string Status { get; set; }

        public ApplicationUser User { get; set; }

    }
}
