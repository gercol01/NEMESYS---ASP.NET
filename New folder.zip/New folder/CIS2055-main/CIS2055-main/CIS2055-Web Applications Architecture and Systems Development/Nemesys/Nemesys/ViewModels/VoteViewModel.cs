﻿using System;
using System.Collections.Generic;
using Nemesys.Models;

namespace Nemesys.ViewModels
{
    public class VoteViewModel
    {
        public int TotalEntries { get; set; }

        public IEnumerable<Vote> Votes { get; set; }


        public int VoteId { get; set; }


        public Report Report { get; set; }

       
        public int ReportId { get; set; }

        public ApplicationUser User { get; set; }


        public string UserId { get; set; }


    }
}
