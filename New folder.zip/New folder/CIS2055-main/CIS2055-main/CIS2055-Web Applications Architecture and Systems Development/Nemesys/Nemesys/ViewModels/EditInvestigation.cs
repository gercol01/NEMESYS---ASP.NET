﻿using System;
using System.ComponentModel.DataAnnotations;
using Nemesys.Models;

namespace Nemesys.ViewModels
{
    public class EditInvestigation
    {
        [Key]
        public int InvId { get; set; }


        public int ReportId { get; set; }

        public Report Report { get; set; }


        [Required(ErrorMessage = "Title is required.")]
        [StringLength(50, MinimumLength = 1)]
        public string InvTitle { get; set; }

        [Required(ErrorMessage = "Date of Hazard is required.")]
        public DateTime DateOfAction { get; set; }

        public string InvPhone{ get; set; }


        public string Status { get; set; }
    }
}


    

