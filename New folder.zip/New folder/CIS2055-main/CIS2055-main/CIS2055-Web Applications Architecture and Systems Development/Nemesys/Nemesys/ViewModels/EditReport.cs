﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Nemesys.ViewModels
{
    public class EditReport
    {
        [Key]
        public int ReportId { get; set; }

        public string UserId { get; set; }

        [Required(ErrorMessage = "Title is required.")]
        [StringLength(50, MinimumLength = 1)]
        public string Title { get; set; }

        [Required(ErrorMessage = "Description of Hazard is required.")]
        [StringLength(1500, MinimumLength = 1, ErrorMessage = "Report cannot be longer than 1500 characters.")]
        public string Content { get; set; }

        [Required(ErrorMessage = "Location of Hazard is required.")]
        public string Location { get; set; }

        [Required(ErrorMessage = "Date of Hazard is required.")]
        public DateTime DateOfHazard { get; set; }

        [Required(ErrorMessage = "Type of Hazard is required.")]
        public string TypeOfHazard { get; set; }

        [Display(Name = "Image of Hazard")]
        public string Photo { get; set; }



    }
}





