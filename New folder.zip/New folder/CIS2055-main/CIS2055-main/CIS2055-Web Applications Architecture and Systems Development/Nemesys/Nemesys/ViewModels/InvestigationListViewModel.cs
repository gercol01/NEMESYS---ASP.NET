﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Nemesys.Models;

namespace Nemesys.ViewModels {
    public class InvestigationListViewModel
    {

        public int TotalEntries { get; set; }

        public IEnumerable<Investigation> Investigations { get; set; }




        public int InvId { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        public DateTime DateOfAction { get; set; }
        public string InvTitle { get; set; }
        public string InvContent { get; set; }

        public int InvPhone { get; set; }


        public ApplicationUser User { get; set; }



        public Report Report { get; set; }


    }
        
    }
