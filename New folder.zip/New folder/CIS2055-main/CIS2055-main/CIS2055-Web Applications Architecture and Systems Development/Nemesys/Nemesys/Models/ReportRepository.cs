﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nemesys.Models;

namespace Nemesys.Models
{
    public class ReportRepository : IReportRepository
    {
        private readonly ApplicationDbContext appDbContext;
        private readonly ILogger<ReportRepository> _logger;

        public ReportRepository(ApplicationDbContext _appDbContext, ILogger<ReportRepository> logger) { 
        
            appDbContext = _appDbContext;
            _logger = logger;
        }

        public IEnumerable<Report> GetAllReports()
        {
            try
            {
                return appDbContext.Reports;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public Report GetReportsById(int reportId)
        {
            try
            {
                return appDbContext.Reports.Include(b => b.User).FirstOrDefault(p => p.ReportId == reportId);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }


        
        public void Create(Report newReport)
        {
            try
            {

            appDbContext.Reports.Add(newReport);
            appDbContext.SaveChanges();

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public void Update(Report report)
        {
            try
            {
                var existingReport = appDbContext.Reports.SingleOrDefault(r => r.ReportId == report.ReportId);
            if (existingReport != null)
            {
                existingReport.Title = report.Title;
                existingReport.Content = report.Content;
                existingReport.CreatedDate = report.CreatedDate;
                existingReport.TypeOfHazard = report.TypeOfHazard;
                existingReport.DateOfHazard = report.DateOfHazard;
                existingReport.Photo = report.Photo;

                appDbContext.Entry(existingReport).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                appDbContext.SaveChanges();
            }
        }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }


        public void Delete(int reportId)
        {
            try
            {
                var report = appDbContext.Reports.Find(reportId);
                if (report != null)
                {
                    appDbContext.Reports.Remove(report);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public void Save()
        {
            appDbContext.SaveChanges();
        }

       






    }
}
