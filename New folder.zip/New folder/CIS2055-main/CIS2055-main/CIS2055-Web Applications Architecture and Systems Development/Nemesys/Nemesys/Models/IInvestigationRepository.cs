﻿using System;
using System.Collections.Generic;

namespace Nemesys.Models
{
    public interface IInvestigationRepository
    {
        IEnumerable<Investigation> GetAllInvestigations();

        Investigation GetInvestigationsById(int invId);

        void Create(Investigation newInvestigation);

        void Update(Investigation updatedInvestigation);

        void Delete(int invId);

        Report GetReportsById(int reportId);

        void Save();

        Investigation GetInvestigationForReport(int reportId);





    }
}

