﻿using System;
using System.Collections.Generic;

namespace Nemesys.Models
{
    public interface IHomeRepository
    {
     

        public dynamic HOF();

    }
}
