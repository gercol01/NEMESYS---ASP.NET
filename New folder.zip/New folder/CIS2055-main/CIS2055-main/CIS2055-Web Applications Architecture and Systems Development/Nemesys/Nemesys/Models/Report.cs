
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Nemesys.Models;

namespace Nemesys.Models
{
    public class Report
    {
        [Key]
        public int ReportId { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        public DateTime DateOfHazard { get; set; }

        public string Title { get; set; }

        public string Location { get; set; }

        public string TypeOfHazard { get; set; }

        public string Content { get; set; }

        public string Photo { get; set; }

        public string Status { get; set; }

        [Required]
        public ApplicationUser User { get; set; }

        [ForeignKey("UserId")]
        public string UserId { get; set; }


    }
}


