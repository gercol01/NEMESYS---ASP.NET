﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Nemesys.ViewModels;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Nemesys.Models
{
    public class VoteRepository : IVoteRepository
    {
        private readonly ApplicationDbContext appDbContext;
        private readonly ILogger<InvestigationRepository> _logger;



        public VoteRepository(ApplicationDbContext _appDbContext, ILogger<InvestigationRepository> logger)
        {
            appDbContext = _appDbContext; ;
            _logger = logger;
        }

        public IEnumerable<Vote> GetAllVotes()
        {
            try
            {
                return appDbContext.Votes;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }
       


        public void AddVote(Vote newVote)
        {
            try
            {

                Vote vote = new Vote();

                vote.ReportId = newVote.ReportId;
                vote.VoteId = newVote.VoteId;
                vote.User = newVote.User;

                if (appDbContext.Votes.Any(x => x.ReportId == newVote.ReportId && x.User == newVote.User))
                {

                }
                else
                {

                    appDbContext.Votes.Add(newVote);
                    appDbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }



        public void RemoveVote(Vote newVote)
        {
            try
            {

                Vote vote = new Vote();

                vote.ReportId = newVote.ReportId;
                vote.VoteId = newVote.VoteId;
                vote.User = newVote.User;

                if (appDbContext.Votes.Any(x => x.ReportId == newVote.ReportId && x.User == newVote.User))
                {

                }
                else
                {

                    appDbContext.Votes.Remove(newVote);
                    appDbContext.SaveChanges();
                }
            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }


        public Report GetReportsById(int reportId)
        {
            try
            {
                return appDbContext.Reports.SingleOrDefault(p => p.ReportId == reportId);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

    }
}
