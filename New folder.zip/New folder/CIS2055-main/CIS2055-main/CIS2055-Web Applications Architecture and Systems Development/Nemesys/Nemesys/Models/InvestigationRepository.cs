﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;


namespace Nemesys.Models
{
    public class InvestigationRepository : IInvestigationRepository
    {

        private readonly ApplicationDbContext appDbContext;
        private readonly ILogger<InvestigationRepository> _logger;


        public InvestigationRepository(ApplicationDbContext _appDbContext, ILogger<InvestigationRepository> logger)
        {

            appDbContext = _appDbContext;
            _logger = logger;
        }

        public InvestigationRepository(ApplicationDbContext _appDbContext)
        {
            appDbContext = _appDbContext;

        }


        public IEnumerable<Investigation> GetAllInvestigations()
        {
            try
            {
                return appDbContext.Investigations;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public Investigation GetInvestigationsById(int invId)
        {
            try
            {
                return appDbContext.Investigations.Include(b => b.User).FirstOrDefault(p => p.InvId == invId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public void Create(Investigation newInvestigation)
        {
            try
            {
                var existingReport = appDbContext.Reports.SingleOrDefault(r => r.ReportId == newInvestigation.ReportId);
                if (existingReport != null)
                {
                    existingReport.ReportId = newInvestigation.ReportId;
                    existingReport.Status = newInvestigation.Status;


                    appDbContext.Entry(existingReport).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    appDbContext.Investigations.Add(newInvestigation);
                    appDbContext.SaveChanges();

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public void Update(Investigation updatedInvestigation)
        {
            try
            {
                var existingInv = appDbContext.Investigations.SingleOrDefault(r => r.InvId == updatedInvestigation.InvId);
                if (existingInv != null)
                {
                    existingInv.InvTitle = updatedInvestigation.InvTitle;
                    existingInv.InvPhone = updatedInvestigation.InvPhone;
                    existingInv.CreatedDate = updatedInvestigation.CreatedDate;
                    existingInv.DateOfAction = updatedInvestigation.DateOfAction;


                    appDbContext.Entry(existingInv).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    appDbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }


        public void Delete(int invId)
        {
            try
            {
                var investigation = appDbContext.Investigations.Find(invId);
                if (investigation != null) appDbContext.Investigations.Remove(investigation);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public Report GetReportsById(int reportId)
        {
            try
            {
                return appDbContext.Reports.FirstOrDefault(p => p.ReportId == reportId);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

        public void Save()
        {
            appDbContext.SaveChanges();
        }


        public Investigation GetInvestigationForReport(int reportId)
        {
            try
            {
                return appDbContext.Investigations.SingleOrDefault(x => x.ReportId == reportId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                throw;
            }
        }

    }
}

