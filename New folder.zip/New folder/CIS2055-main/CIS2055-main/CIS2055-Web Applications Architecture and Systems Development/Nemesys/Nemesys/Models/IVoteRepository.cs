﻿using System;
using System.Collections.Generic;
using Nemesys.Models;
using Nemesys.ViewModels;

namespace Nemesys.Models
{
    public interface IVoteRepository
    {

        IEnumerable<Vote> GetAllVotes();

        void AddVote(Vote newVote);

        Report GetReportsById(int reportId);

        void RemoveVote(Vote newVote);

    }
}