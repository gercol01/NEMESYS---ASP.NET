﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nemesys.Models;


namespace Nemesys.Models
{
    public class HomeRepository : IHomeRepository
    {
        private readonly ApplicationDbContext appDbContext;
        private readonly ILogger<HomeRepository> _logger;



        public HomeRepository(ApplicationDbContext _appDbContext, ILogger<HomeRepository> logger)
        {

            appDbContext = _appDbContext;
            _logger = logger;
        }



        public dynamic HOF()
        {
            Dictionary<string, int> myDictionary = new Dictionary<string, int>();

            foreach (Report report in appDbContext.Reports)
            {

                string email = appDbContext.Users.Where(p => p.Id.Equals(report.UserId)).FirstOrDefault().Email;

                if (report.CreatedDate.Year.ToString().Equals(DateTime.Now.Year.ToString()))
                {
                    if (myDictionary.ContainsKey(email))
                    {
                        myDictionary[email] += 1;
                    }
                    else
                    {
                        myDictionary.Add(email, 1);
                    }
                }
            }


            var reporters = (from pair in myDictionary
                             orderby pair.Value descending
                             select pair
                        ).Take(15);
            return reporters;
        }




    }
}