﻿using System;

using System.ComponentModel.DataAnnotations;


namespace Nemesys.Models
{
    public class Investigation
    {

        [Key]
        public int InvId { get; set; }

        public DateTime CreatedDate { get; set; }

        public DateTime UpdatedDate { get; set; }

        public DateTime DateOfAction { get; set; }

        public string InvTitle { get; set; }
       
        public string InvPhone { get; set; }
     
        public ApplicationUser User { get; set; }

        public int ReportId { get; set; }

        public string Status { get; set; }

    }

}




