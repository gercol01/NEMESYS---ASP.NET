using System;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using Nemesys.Models;

namespace Nemesys.Models
{
    public class DbInitializer { 


  public static void SeedRoles(RoleManager<IdentityRole> roleManager)
        {
            if (!roleManager.Roles.Any())
            {
                roleManager.CreateAsync(new IdentityRole("Reporter")).Wait();
                roleManager.CreateAsync(new IdentityRole("Investigator")).Wait();
            }
        }

        public static void SeedUsers(UserManager<ApplicationUser> userManager)
        {
            if (!userManager.Users.Any())
            {
                var reporter = new ApplicationUser()
                {
                    Email = "severine@gmail.com",
                    NormalizedEmail = "SEVERINE@GMAIL.COM",
                    UserName = "severine@gmail.com",
                    NormalizedUserName = "SEVERINE@GMAIL.COM",
                    EmailConfirmed = true,
                    PhoneNumberConfirmed = true,
                    SecurityStamp = Guid.NewGuid().ToString("D") 
                };

                //Add to store
                IdentityResult result = userManager.CreateAsync(reporter, "Zo076i?h[").Result;
                if (result.Succeeded)
                {
                    //Add to role
                    userManager.AddToRoleAsync(reporter, "Reporter").Wait();
                }

                var investigator = new ApplicationUser()
                {
                    Email = "gerard@gmail.com",
                    NormalizedEmail = "GERARD@GMAIL.COM",
                    UserName = "gerard@gmail.com",
                    NormalizedUserName = "GERARD@GMAIL.COM",
                    EmailConfirmed = true,
                    PhoneNumberConfirmed = true,
                    SecurityStamp = Guid.NewGuid().ToString("D") 
                };

                result = userManager.CreateAsync(investigator, "Zo076i?h[").Result;
                if (result.Succeeded)
                {
                    //Add to role
                    userManager.AddToRoleAsync(investigator, "Investigator").Wait();
                }
            }
        }

        public static void SeedData(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            SeedRoles(roleManager);
            SeedUsers(userManager);
        }

    }
}



