﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Nemesys.Models;

namespace Nemesys.Controllers
{
    public class HomeController : Controller
    {

        private readonly IHomeRepository _homeRepository;
        private readonly ILogger<HomeController> _logger;


        public HomeController(IHomeRepository homeRepository, ILogger<HomeController> logger)
        {

            _homeRepository = homeRepository;
            _logger = logger;
        }


        public IActionResult Index()
        {
            try
            {
                return View();

            }

            catch (Exception ex)
            {
                _logger.LogError("Details action: " + ex.Message);
                return View("Error");
            }

        }


        public IActionResult About()
        {
            try
            {

                return View();
            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }


        public IActionResult HallOfFame()
        {
            try
            {
                var List = _homeRepository.HOF();
                List<HallOfFame> list = new List<HallOfFame>();

                foreach (var item in List)
                {
                    HallOfFame hallOfFame = new HallOfFame();

                    hallOfFame.Reporter = item.Key;
                    hallOfFame.ReportCounter = item.Value;

                    list.Add(hallOfFame);
                }
                return View(list);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }


        public IActionResult Error()
        {
            return View();
        }

    }
}





