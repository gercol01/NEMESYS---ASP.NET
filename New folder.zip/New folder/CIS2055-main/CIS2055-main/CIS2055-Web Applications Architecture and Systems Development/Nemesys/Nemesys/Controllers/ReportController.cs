﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Nemesys.ViewModels;
using Nemesys.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.Web.CodeGeneration;

namespace Nemesys.Controllers
{
    public class ReportController : Controller
    {
        private readonly IReportRepository _reportRepository;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<ReportController> _logger;


        public ReportController(IReportRepository reportRepository, UserManager<ApplicationUser> userManager, ILogger<ReportController> logger)
        {
            _reportRepository = reportRepository;
            _userManager = userManager;
            _logger = logger;
        }


        public IActionResult Error()
        {
            return View();
        }


        [HttpGet]
        [ResponseCache(Duration = 20, Location = ResponseCacheLocation.Client)]
        public IActionResult Index(string keyword)
        {

            try
            {
                _logger.LogInformation("Information");
                _logger.LogWarning("Warning");
                _logger.LogError("Error");
                _logger.LogCritical("Critical");

                ViewBag.Title = "Report Index View";

                var model = new ReportListViewModel();
                model.Reports = _reportRepository.GetAllReports().OrderByDescending(p => p.CreatedDate);
                model.TotalEntries = model.Reports.Count();

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }



        [HttpGet]
        public IActionResult Details(int id)
        {
            try
            {
                var post = _reportRepository.GetReportsById(id);


                if (post == null)
                    return NotFound();
                else
                    return View(post);
            }
            catch (Exception ex)
            {
                _logger.LogError("Details action: " + ex.Message);
                return View("Error");
            }
        }

        [HttpGet]
        [Authorize(Roles = "Reporter")]
        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [Authorize(Roles = "Reporter")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Title,Content,Location,DateOfHazard,TypeOfHazard,Photo")] EditReport newReport, IFormFile file)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    if (file == null || file.Length == 0)
                    {
                        newReport.Photo = "noimage.png";
                    }
                    else
                    {
                        string filename = System.Guid.NewGuid().ToString() + ".jpg";
                        var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", filename);
                        using (var stream = new FileStream(path, FileMode.Create))
                        {
                            await file.CopyToAsync(stream);
                        }
                        newReport.Photo = filename;

                    }




                    Report report = new Report()
                    {
                        User = await _userManager.GetUserAsync(User),
                        Title = newReport.Title,
                        Content = newReport.Content,
                        Location = newReport.Location,
                        DateOfHazard = newReport.DateOfHazard,
                        TypeOfHazard = newReport.TypeOfHazard,
                        Photo = newReport.Photo,
                        CreatedDate = DateTime.UtcNow,
                        Status = "Open",
                    };




                    _logger.LogInformation("User" + User.Identity.Name + " created a report");

                    _reportRepository.Create(report);
                    return RedirectToAction("Index");
                }
                else
                {
                    return View(newReport);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }




        [HttpGet]
        [Authorize(Roles = "Reporter")]
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var existingReport = _reportRepository.GetReportsById(id);
                if (existingReport != null)
                {
                    var currentUser = await _userManager.GetUserAsync(User);
                    if (existingReport.User.Id == currentUser.Id)
                    {
                        EditReport model = new EditReport()
                        {
                            ReportId = existingReport.ReportId,
                            Title = existingReport.Title,
                            Content = existingReport.Content,
                            Location = existingReport.Location,
                            DateOfHazard = existingReport.DateOfHazard,
                            TypeOfHazard = existingReport.TypeOfHazard,
                            Photo = existingReport.Photo,



                        };

                        return View(model);
                    }
                    else
                        return Unauthorized();
                }
                else
                    return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Reporter")]
        public async Task<IActionResult> Edit(int id, [Bind("ReportId,Title,Content,Location,DateOfHazard,TypeOfHazard,Photo")] EditReport updatedReport, IFormFile file)
        {
            try
            {
                if (id != updatedReport.ReportId)
                {
                    return NotFound();
                }

                var existingReport = _reportRepository.GetReportsById(id);
                if (existingReport != null)
                {
                    var currentUser = await _userManager.GetUserAsync(User);
                    if (existingReport.User.Id == currentUser.Id)
                    {
                        if (ModelState.IsValid)
                        {
                            if (file == null || file.Length == 0)
                            {
                                updatedReport.Photo = "noimage.png";
                            }
                            else
                            {
                                string filename = System.Guid.NewGuid().ToString() + ".jpg";
                                var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", filename);
                                using (var stream = new FileStream(path, FileMode.Create))
                                {
                                    await file.CopyToAsync(stream);
                                }
                                updatedReport.Photo = filename;

                            }


                            Report updatedRep = new Report()
                            {
                                User = await _userManager.GetUserAsync(User),
                                ReportId = updatedReport.ReportId,
                                Title = updatedReport.Title,
                                Content = updatedReport.Content,
                                Location = updatedReport.Location,
                                DateOfHazard = updatedReport.DateOfHazard,
                                TypeOfHazard = updatedReport.TypeOfHazard,
                                Photo = updatedReport.Photo,
                                CreatedDate = DateTime.UtcNow,
                                UpdatedDate = DateTime.UtcNow,
                                Status = existingReport.Status

                            };

                            _reportRepository.Update(updatedRep);
                            return RedirectToAction("Index");
                        }
                        else
                            return View(updatedReport);
                    }
                    return Unauthorized();
                }
                else
                    return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }

        [Authorize(Roles = "Investigator")]
        [HttpGet]
        public async Task<IActionResult> Dashboard()
        {
            try
            {
                ViewBag.Title = "Nemesys Dashboard";
                var model = new ReportDashboardViewModel();
                model.TotalRegisteredUsers = _userManager.Users.Count();
                model.TotalEntries = _reportRepository.GetAllReports().Count();

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }



        [HttpGet]
        [Authorize(Roles = "Reporter")]
        public async Task<IActionResult> Delete(int id)
        {

            try
            {

                var existingReport = _reportRepository.GetReportsById(id);
                if (existingReport != null)
                {
                    var currentUser = await _userManager.GetUserAsync(User);
                    if (existingReport.User.Id == currentUser.Id)
                    {

                        return View(existingReport);
                    }
                    else
                        return Unauthorized();
                }
                else
                    return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }


        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult ConfirmDelete(int id)
        {
            try
            {
                _reportRepository.Delete(id);
                _reportRepository.Save();
                return RedirectToAction("Index", "Report");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }



        }
    }
}