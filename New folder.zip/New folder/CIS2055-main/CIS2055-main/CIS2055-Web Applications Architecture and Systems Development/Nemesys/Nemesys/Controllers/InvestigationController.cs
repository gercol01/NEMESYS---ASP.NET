﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Nemesys.Models;
using Nemesys.ViewModels;

namespace Nemesys.Controllers
{
    public class InvestigationController : Controller
    {

        private readonly IInvestigationRepository _invRepository;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<InvestigationController> _logger;



        public InvestigationController(IInvestigationRepository invRepository, UserManager<ApplicationUser> userManager, ILogger<InvestigationController> logger)
        {

            _invRepository = invRepository;
            _userManager = userManager;
            _logger = logger;
        }



        public IActionResult Error()
        {
            return View();
        }


        [HttpGet]
        [ResponseCache(Duration = 20, Location = ResponseCacheLocation.Client)]
        public IActionResult Index(string keyword)
        {

            try
            {
                _logger.LogInformation("Information");
                _logger.LogWarning("Warning");
                _logger.LogError("Error");
                _logger.LogCritical("Critical");

                ViewBag.Title = "Investigation Index View";

                var model = new InvestigationListViewModel();
                model.Investigations = _invRepository.GetAllInvestigations().OrderByDescending(p => p.CreatedDate);
                model.TotalEntries = model.Investigations.Count();

                return View(model);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }




        [HttpGet]
        public IActionResult Details(int id)
        {
            try
            {
                var post = _invRepository.GetInvestigationsById(id);

                if (post == null)
                    return NotFound();
                else
                    return View(post);
            }
            catch (Exception ex)
            {
                _logger.LogError("Details action: " + ex.Message);
                return View("Error");
            }
        }




        [Authorize(Roles = "Investigator")]
        public async Task<IActionResult> Create(int id)
        {
            try
            {
                var report = _invRepository.GetReportsById(id);
                if (report != null)
                {

                    EditInvestigation investigation = new EditInvestigation()
                    {
                        ReportId = report.ReportId,
                        Status = report.Status,
                    };

                    return View(investigation);
                }

                return View("Index");
            }

            catch (Exception ex)
            {
                _logger.LogError("Details action: " + ex.Message);
                return View("Error");
            }
        }




        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Investigator")]
        public async Task<IActionResult> Create(int id, [Bind("ReportId,InvTitle,InvContent,DateOfAction,InvPhone,Status")] EditInvestigation newInvestigation)
        {

            try
            {
                if (id != newInvestigation.ReportId)
                {
                    return NotFound();
                }

                var existingReport = _invRepository.GetReportsById(id);

                if (existingReport != null)
                {
                    if (ModelState.IsValid)
                    {

                        Investigation inv = new Investigation()
                        {
                            ReportId = newInvestigation.ReportId,
                            User = await _userManager.GetUserAsync(User),
                            InvTitle = newInvestigation.InvTitle,
                            DateOfAction = newInvestigation.DateOfAction,
                            InvPhone = newInvestigation.InvPhone,
                            Status = newInvestigation.Status,
                            CreatedDate = DateTime.UtcNow


                        };



                        _logger.LogInformation("User" + User.Identity.Name + " created an investigation");

                        _invRepository.Create(inv);
                        return RedirectToAction("Index");

                    }
                    else
                    {
                        return View(newInvestigation);
                    }
                }


                else
                {
                    return RedirectToAction("Index");

                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }



        [HttpGet]
        [Authorize(Roles = "Investigator")]
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var existingInv = _invRepository.GetInvestigationsById(id);
                if (existingInv != null)
                {
                    var currentUser = await _userManager.GetUserAsync(User);
                    if (existingInv.User.Id == currentUser.Id)
                    {
                        EditInvestigation model = new EditInvestigation()
                        {
                            InvId = existingInv.InvId,
                            InvTitle = existingInv.InvTitle,
                            DateOfAction = existingInv.DateOfAction,
                            InvPhone = existingInv.InvPhone,
                            Status = existingInv.Status


                        };

                        return View(model);
                    }
                    else
                        return Unauthorized();
                }
                else
                    return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Investigator")]
        public async Task<IActionResult> Edit(int id, [Bind("InvId,InvTitle,InvContent,DateOfAction,InvPhone")] EditInvestigation updatedInvestigation)
        {
            try
            {
                if (id != updatedInvestigation.InvId)
                {
                    return NotFound();
                }

                var existingInv = _invRepository.GetInvestigationsById(id);
                if (existingInv != null)
                {
                    var currentUser = await _userManager.GetUserAsync(User);
                    if (existingInv.User.Id == currentUser.Id)
                    {
                        if (ModelState.IsValid)
                        {


                            Investigation updatedInv = new Investigation()
                            {
                                User = await _userManager.GetUserAsync(User),
                                InvId = updatedInvestigation.InvId,
                                InvTitle = updatedInvestigation.InvTitle,
                                DateOfAction = updatedInvestigation.DateOfAction,
                                InvPhone = updatedInvestigation.InvPhone,
                                Status = updatedInvestigation.Status,
                                CreatedDate = DateTime.UtcNow


                            };


                            _invRepository.Update(updatedInv);
                            return RedirectToAction("Index");
                        }
                        else
                            return View(updatedInvestigation);
                    }
                    return Unauthorized();
                }
                else
                    return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }



        [HttpGet]
        [Authorize(Roles = "Investigator")]
        public async Task<IActionResult> Delete(int id)
        {


            try
            {
                var existingInv = _invRepository.GetInvestigationsById(id);
                if (existingInv != null)
                {
                    var currentUser = await _userManager.GetUserAsync(User);
                    if (existingInv.User.Id == currentUser.Id)
                    {


                        return View(existingInv);
                    }
                    else
                        return Unauthorized();
                }
                else
                    return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }


        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult ConfirmDelete(int id)
        {
            try
            {
                _invRepository.Delete(id);
                _invRepository.Save();
                return RedirectToAction("Index", "Home");
            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }



    }


}



