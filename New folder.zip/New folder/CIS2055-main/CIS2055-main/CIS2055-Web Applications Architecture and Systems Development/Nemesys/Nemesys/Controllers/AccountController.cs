﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Nemesys.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Nemesys.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;

namespace Nemesys.Controllers
{
    public class AccountController : Controller
    {
        private readonly SignInManager<ApplicationUser> _signinManager;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<AccountController> _logger;

        public AccountController(SignInManager<ApplicationUser> signInManager, UserManager<ApplicationUser> userManager)
        {
            _signinManager = signInManager;
            _userManager = userManager;

        }

        public IActionResult Error()
        {
            return View();
        }


        public IActionResult Login(string returnUrl)
        {
            try
            {

                ViewData["ReturnUrl"] = returnUrl;
                return View();

            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> Login(LogInViewModel loginViewModel, string returnUrl)
        {

            try
            {
                if (!ModelState.IsValid)
                    return View(loginViewModel);

                var reporter = await _userManager.FindByNameAsync(loginViewModel.Username);

                if (reporter != null)
                {
                    var result = await _signinManager.PasswordSignInAsync(reporter, loginViewModel.Password, false, false);
                    if (result.Succeeded)
                    {
                        if (!String.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                            return LocalRedirect(returnUrl);
                        else
                            return RedirectToAction("Index", "Home");
                    }
                }

                ModelState.AddModelError("", "User name or password not correct");
                return View(loginViewModel);

            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }


        public IActionResult Register(string returnUrl)
        {
            try
            {
                return View();
            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel registerViewModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var reporter = new ApplicationUser()
                    {

                        UserName = registerViewModel.Username,
                        FirstName = registerViewModel.FirstName,
                        LastName = registerViewModel.LastName,
                        Gender = registerViewModel.Gender,
                        Email = registerViewModel.Email,
                        PhoneNumber = registerViewModel.Phone

                    };

                    var result = await _userManager.CreateAsync(reporter, registerViewModel.Password);

                    if (result.Succeeded)
                    {
                        await _userManager.AddToRoleAsync(reporter, "Reporter");
                        return RedirectToAction("Index", "Home");
                    }

                    ModelState.AddModelError("", result.Errors.First().Description);
                }

                return View(registerViewModel);

            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }



        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            try
            {

                await _signinManager.SignOutAsync();
                return RedirectToAction("Index", "Home");

            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }

        }


        [HttpGet]
        [AllowAnonymous]
        public IActionResult ForgotPassword()
        {
            try
            {
                return View();
            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    var user = await _userManager.FindByEmailAsync(model.Email);

                    if (user != null && await _userManager.IsEmailConfirmedAsync(user))
                    {

                        var token = await _userManager.GeneratePasswordResetTokenAsync(user);


                        var passwordResetLink = Url.Action("ResetPassword", "Account",
                                new { email = model.Email, token = token }, Request.Scheme);


                        return View("ForgotPasswordConfirmation");
                    }


                    return View("ForgotPasswordConfirmation");
                }

                return View(model);

            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult ResetPassword(string token, string email)
        {
            try
            {

                if (token == null || email == null)
                {
                    ModelState.AddModelError("", "Invalid password reset token");
                }
                return View();

            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public async Task<IActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    var user = await _userManager.FindByEmailAsync(model.Email);

                    if (user != null)
                    {

                        var result = await _userManager.ResetPasswordAsync(user, model.Token, model.Password);
                        if (result.Succeeded)
                        {
                            return View("ResetPasswordConfirmation");

                        }

                        foreach (var error in result.Errors)
                        {
                            ModelState.AddModelError("", error.Description);
                        }
                        return View(model);
                    }


                    return View("ResetPasswordConfirmation");
                }

                return View(model);

            }

            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return View("Error");
            }


        }
    }
}