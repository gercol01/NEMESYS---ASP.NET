﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Nemesys.Models;
using Nemesys.ViewModels;

namespace Nemesys.Controllers

{
    public class VoteController : Controller
    {
        private readonly IVoteRepository _voteRepository;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ILogger<VoteController> _logger;

        public VoteController(IVoteRepository repository, UserManager<ApplicationUser> userManager, ILogger<VoteController> logger)
        {
            _voteRepository = repository;
            _userManager = userManager;
            _logger = logger;
        }

        public IActionResult Error()
        {
            return View();
        }


        [Authorize(Roles = "Reporter")]
        public async Task<IActionResult> Add(int id)
        {
            var report = _voteRepository.GetReportsById(id);
            if (report != null)
            {

                Vote vote = new Vote()
                {
                    User = await _userManager.GetUserAsync(User),
                    ReportId = report.ReportId,



                };

                _voteRepository.AddVote(vote);
                return RedirectToAction("Index", "Report");

            }

            return View("Index");
        }




        [Authorize(Roles = "Reporter")]
        public async Task<IActionResult> Remove(int id)
        {
            var report = _voteRepository.GetReportsById(id);
            if (report != null)
            {

                Vote vote = new Vote()
                {
                    User = await _userManager.GetUserAsync(User),
                    ReportId = report.ReportId,



                };

                _voteRepository.RemoveVote(vote);
                return RedirectToAction("Index", "Report");

            }

            return View("Index");
        }

    }
}